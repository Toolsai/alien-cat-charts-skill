/* ===== core.js ===== */
/* Alien Journey — core kit (original work, MIT).
   Kit.*       DOM/SVG helpers, text-fit system (never overflows), tween helpers, code-drawn decorations
   Journey.*   chart registry, chart mount (stage + controls + status), page boot, index map, visited tracking
   Loaded on every page after window.JOURNEY (data) and window.PAGE_ID are defined by build_site.py. */
(function () {
  'use strict';
  const Kit = (window.Kit = {});
  const Journey = (window.Journey = { charts: {} });
  const SVGNS = 'http://www.w3.org/2000/svg';
  const J = () => window.JOURNEY;
  Kit.reduced = !!(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches);

  /* ---------- DOM helpers ---------- */
  Kit.h = function (tag, cls, attrs, kids) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (attrs) for (const k in attrs) { if (k === 'style') e.style.cssText = attrs[k]; else e.setAttribute(k, attrs[k]); }
    if (kids) [].concat(kids).forEach(c => c != null && e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c));
    return e;
  };
  Kit.s = function (tag, attrs, kids) {
    const e = document.createElementNS(SVGNS, tag);
    if (attrs) for (const k in attrs) e.setAttribute(k, attrs[k]);
    if (kids) [].concat(kids).forEach(c => c && e.appendChild(c));
    return e;
  };
  Kit.assetUrl = p => ((J() && J().assets) || 'assets/') + p;
  Kit.spriteUrl = name => Kit.assetUrl('sprites/' + name + '.webp');
  Kit.sprite = function (name, cls) {
    const i = new Image();
    i.src = Kit.spriteUrl(name); i.alt = ''; i.draggable = false; i.className = 'sprite' + (cls ? ' ' + cls : '');
    return i;
  };
  Kit.rng = function (seed) { let s = seed >>> 0 || 1; return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296); };
  Kit.clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  Kit.lerp = (a, b, t) => a + (b - a) * t;
  Kit.pick = (arr, i) => arr[((i % arr.length) + arr.length) % arr.length];
  Kit.CAST = ['cat_wave', 'alien_green', 'blob_buddy', 'space_dog', 'tentacle_buddy', 'robot_buddy', 'cat_point', 'cat_cheer', 'cat_think'];
  Kit.fixSprite = n => (Kit.CAST.concat(['cat_head', 'ufo', 'ufo_pink']).indexOf(n) >= 0 ? n : null);

  /* ---------- TEXT FITTING ----------
     A "fit box" is any element with a CSS-defined size (flex/grid child needs min-width:0/min-height:0; .fit has it).
     Kit.text(box, str, {min,max,left,nowrap}) puts the text inside <span.ft>. Kit.fitOne chooses the largest
     font-size in [min,max] that fits; if even `min` overflows the text is line-clamped with "…" (full text in title). */
  Kit.text = function (box, str, o) {
    o = o || {};
    box.classList.add('fit');
    if (o.left) box.classList.add('left');
    if (o.min) box.dataset.min = o.min;
    if (o.max) box.dataset.max = o.max;
    if (o.nowrap) box.dataset.nowrap = '1';
    let ft = box.firstElementChild && box.firstElementChild.classList.contains('ft') ? box.firstElementChild : null;
    if (!ft) { box.textContent = ''; ft = document.createElement('span'); ft.className = 'ft'; box.appendChild(ft); }
    ft.textContent = str == null ? '' : String(str);
    return box;
  };
  Kit.fb = function (cls, str, o, attrs) { return Kit.text(Kit.h('div', cls || '', attrs), str, o); };
  Kit.fitOne = function (box) {
    const ft = box.firstElementChild;
    if (!ft || !ft.classList.contains('ft')) return;
    const cs = getComputedStyle(box);
    const aw = box.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    const ah = box.clientHeight - parseFloat(cs.paddingTop) - parseFloat(cs.paddingBottom);
    if (aw <= 2 || ah <= 2) return;
    const min = +box.dataset.min || 10, max = +box.dataset.max || 22;
    ft.classList.remove('clamp'); ft.style.webkitLineClamp = ''; box.removeAttribute('data-clamped'); box.removeAttribute('title');
    const fits = () => ft.offsetHeight <= ah + 0.5 && ft.scrollWidth <= aw + 0.5;
    ft.style.whiteSpace = '';
    const search = (lo, hi) => { while (hi - lo > 0.5) { const mid = (lo + hi) / 2; box.style.fontSize = mid + 'px'; if (fits()) lo = mid; else hi = mid; } box.style.fontSize = lo + 'px'; box.dataset.fs = lo; };
    if (box.dataset.nowrap) {
      ft.style.whiteSpace = 'nowrap'; box.style.fontSize = min + 'px';
      if (fits()) { box.style.fontSize = max + 'px'; if (fits()) { box.dataset.fs = max; return; } search(min, max); return; }
      ft.style.whiteSpace = '';
    }
    box.style.fontSize = max + 'px';
    if (fits()) { box.dataset.fs = max; return; }
    box.style.fontSize = min + 'px';
    if (fits()) { search(min, max); return; }
    const lh = parseFloat(getComputedStyle(ft).lineHeight) || min * 1.25;
    const lines = Math.max(1, Math.floor(ah / lh));
    ft.classList.add('clamp'); ft.style.webkitLineClamp = lines;
    for (let n = lines; n > 1 && ft.offsetHeight > ah + 0.5; n--) ft.style.webkitLineClamp = n - 1;
    box.dataset.clamped = '1'; box.dataset.fs = min; box.title = ft.textContent;
  };
  Kit.fitAll = function (root) { (root || document).querySelectorAll('.fit').forEach(Kit.fitOne); };
  Kit.setText = function (box, str) { Kit.text(box, str); Kit.fitOne(box); };

  /* ---------- timing ---------- */
  Kit.sleep = ms => new Promise(r => setTimeout(r, Kit.reduced ? Math.min(ms, 80) : ms));
  Kit.ease = { inOut: t => (t < .5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2), out: t => 1 - Math.pow(1 - t, 3), lin: t => t };
  Kit.tween = function (ms, fn, ease) {
    ms = Kit.reduced ? Math.min(ms, 120) : ms;
    let raf, stop = false, res;
    const done = new Promise(r => (res = r));
    const t0 = performance.now(), e = ease || Kit.ease.inOut;
    const step = now => {
      if (stop) return;
      const t = Math.min(1, (now - t0) / Math.max(1, ms));
      fn(e(t));
      if (t < 1) raf = requestAnimationFrame(step); else res(true);
    };
    raf = requestAnimationFrame(step);
    return { done, cancel() { stop = true; cancelAnimationFrame(raf); res(false); } };
  };
  Kit.samplePath = function (path, n) {
    const L = path.getTotalLength(), pts = [];
    for (let i = 0; i <= n; i++) { const p = path.getPointAtLength(L * i / n); pts.push({ x: p.x, y: p.y }); }
    return pts;
  };
  Kit.polyLen = pts => pts.reduce((a, p, i) => (i ? a + Math.hypot(p.x - pts[i - 1].x, p.y - pts[i - 1].y) : 0), 0);
  Kit.polyAt = function (pts, d) {
    let acc = 0;
    for (let i = 1; i < pts.length; i++) {
      const seg = Math.hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y);
      if (acc + seg >= d || i === pts.length - 1) { const k = seg ? Math.min(1, (d - acc) / seg) : 0; return { x: pts[i - 1].x + (pts[i].x - pts[i - 1].x) * k, y: pts[i - 1].y + (pts[i].y - pts[i - 1].y) * k }; }
      acc += seg;
    }
    return { x: pts[0].x, y: pts[0].y };
  };

  /* ---------- code-drawn decorations ---------- */
  Kit.planet = function (size, o) {
    o = o || {};
    const c1 = o.c1 || '#ff5fa8', c2 = o.c2 || '#c2307a', id = 'pg' + Math.random().toString(36).slice(2, 7);
    const svg = Kit.s('svg', { viewBox: '-60 -60 120 120', width: size, height: size });
    const defs = Kit.s('defs'); svg.appendChild(defs);
    const clip = Kit.s('clipPath', { id }); clip.appendChild(Kit.s('circle', { r: 40 })); defs.appendChild(clip);
    if (o.ring) { svg.appendChild(Kit.s('ellipse', { rx: 58, ry: 15, fill: 'none', stroke: '#17123a', 'stroke-width': 11, transform: 'rotate(-18)' })); svg.appendChild(Kit.s('ellipse', { rx: 58, ry: 15, fill: 'none', stroke: o.ringc || '#ffd93b', 'stroke-width': 5, transform: 'rotate(-18)' })); }
    svg.appendChild(Kit.s('circle', { r: 40, fill: c1, stroke: '#17123a', 'stroke-width': 5 }));
    const g = Kit.s('g', { 'clip-path': `url(#${id})` });
    g.appendChild(Kit.s('path', { d: 'M-50 10 Q0 -8 50 12 L50 50 L-50 50Z', fill: c2 }));
    g.appendChild(Kit.s('circle', { cx: -14, cy: -14, r: 8, fill: c2, opacity: .8 }));
    g.appendChild(Kit.s('circle', { cx: 15, cy: 22, r: 6, fill: '#fff', opacity: .35 }));
    svg.appendChild(g);
    if (o.ring) { const d = 'M-58 0 A58 15 0 0 0 58 0'; svg.appendChild(Kit.s('path', { d, fill: 'none', stroke: '#17123a', 'stroke-width': 11, transform: 'rotate(-18)', 'stroke-linecap': 'round' })); svg.appendChild(Kit.s('path', { d, fill: 'none', stroke: o.ringc || '#ffd93b', 'stroke-width': 5, transform: 'rotate(-18)', 'stroke-linecap': 'round' })); }
    return svg;
  };
  Kit.PLANET_COLORS = [['#ff5fa8', '#c2307a'], ['#5ef0c8', '#2fa58a'], ['#ffd93b', '#e0a000'], ['#8a5cf0', '#5a35b8'], ['#59d7ff', '#2a8ec4'], ['#ff9340', '#d4601a'], ['#a8e86a', '#5aa02a'], ['#ff7b7b', '#c23a3a']];

  /* ---------- progress memory (visited sections) ---------- */
  const store = {
    get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
    set(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  };
  Kit.store = store;
  Journey.visited = function () { try { return JSON.parse(store.get('aj-visited-' + J().id) || '[]'); } catch (e) { return []; } };
  Journey.markVisited = function (id) { const v = Journey.visited(); if (v.indexOf(id) < 0) { v.push(id); store.set('aj-visited-' + J().id, JSON.stringify(v)); } };

  /* ---------- chart registry & mount ---------- */
  Journey.register = (type, fn) => { Journey.charts[type] = fn; };
  Journey.mountChart = function (panel, section, idx) {
    const fn = Journey.charts[section.chartType];
    if (!fn) throw new Error('Unknown chartType: ' + section.chartType);
    const mascotName = Kit.fixSprite(section.mascot) || Kit.pick(Kit.CAST, idx);
    const stage = Kit.h('div', 'stage'), controls = Kit.h('div', 'controls', { role: 'group', 'aria-label': 'chart controls' });
    const stText = Kit.fb('status', '', { min: 11, max: 18, left: true }); stText.setAttribute('aria-live', 'polite');
    const statusbar = Kit.h('div', 'statusbar', null, [Kit.sprite('cat_head'), stText]);
    panel.append(stage, controls, statusbar);
    const btn = {};
    const ctx = {
      data: section.data || {}, section, index: idx, stage, panel, mascot: mascotName, narrow: false,
      sprite: Kit.sprite,
      say(msg) { Kit.setText(stText, msg); statusbar.classList.remove('pop'); void statusbar.offsetWidth; statusbar.classList.add('pop'); window.__lastStatus = msg; },
      setButtons(list) {
        if (list.length > 4) throw new Error('at most 4 control buttons');
        controls.textContent = '';
        list.forEach(b => {
          const e = Kit.h('button', 'btn ' + (b.cls || ''), { type: 'button', id: 'btn-' + b.id });
          const lab = Kit.fb('', b.label, { min: 10, max: 17, nowrap: true }); lab.style.cssText = 'flex:1;min-width:0;height:100%'; e.appendChild(lab);
          e.addEventListener('click', () => { if (!e.disabled) b.on(); });
          controls.appendChild(e); btn[b.id] = e;
        });
        Kit.fitAll(controls);
      },
      label(id, text) { const l = btn[id].firstElementChild; Kit.text(l, text, { min: 10, max: 17, nowrap: true }); Kit.fitOne(l); },
      enable(id, on) { if (btn[id]) { btn[id].disabled = !on; btn[id].classList.toggle('off', !on); } },
      height(px) { stage.style.height = Math.round(px) + 'px'; }
    };
    const api = fn(ctx) || {};
    let lastW = -1, raf = 0;
    const run = () => {
      lastW = panel.clientWidth;
      ctx.narrow = panel.classList.toggle('narrow', lastW < 640);
      if (api.layout) api.layout(ctx.narrow, stage.clientWidth);
      Kit.fitAll(panel);
    };
    Kit.ready.then(() => {
      run(); window.__kitReady = true;
      new ResizeObserver(() => { cancelAnimationFrame(raf); raf = requestAnimationFrame(() => { if (panel.clientWidth !== lastW) run(); }); }).observe(panel);
      if (document.fonts && document.fonts.addEventListener) document.fonts.addEventListener('loadingdone', () => Kit.fitAll(panel));
    });
    Journey.chart = { ctx, api, btn };
    return ctx;
  };
  Kit.ready = Promise.race([document.fonts ? document.fonts.ready : Promise.resolve(), new Promise(r => setTimeout(r, 2500))]);

  /* test hook: replace every fit box's text with ~400 chars + a 60-char unbroken word, then refit */
  window.__stress = function (root) {
    const long = '這是一段很長很長的壓力測試文字，用來確認文字永遠不會走出框外。 '.repeat(8) + ' Supercalifragilisticexpialidocious_Supercalifragilisticexpialidocious_ok';
    (root || document).querySelectorAll('.fit').forEach(b => { if (b.closest('.topbar') || b.classList.contains('tb-title') || b.clientWidth < 48) return; const ft = b.firstElementChild; if (ft && ft.classList.contains('ft')) ft.textContent = long; });
    Kit.fitAll(root || document);
  };

  /* ---------- page boot ---------- */
  Journey.boot = function () {
    const jd = J(), pid = window.PAGE_ID;
    const sections = jd.sections;
    document.documentElement.lang = jd.lang || 'zh-Hant';
    // background
    const bgEl = document.getElementById('bg');
    const idx = sections.findIndex(s => s.id === pid);
    const theme = pid === 'index' ? (jd.indexBackground || 'starfield') : (sections[idx] && sections[idx].background) || 'starfield';
    if (window.Bg) Bg.mount(bgEl, theme, idx);
    // title fit boxes (top bar)
    document.querySelectorAll('.tb-title').forEach(b => Kit.text(b, b.textContent, { min: 12, max: 18, left: true }));
    // visited dots
    const vis = Journey.visited();
    if (pid !== 'index') Journey.markVisited(pid);
    const vis2 = Journey.visited();
    document.querySelectorAll('.dot[data-id]').forEach(d => d.classList.toggle('visited', vis2.indexOf(d.dataset.id) >= 0 && d.dataset.id !== pid));
    // keyboard: left/right = previous/next page (ignored while typing / with modifiers)
    document.addEventListener('keydown', e => {
      if (e.altKey || e.ctrlKey || e.metaKey || /input|textarea|select/i.test((e.target.tagName || ''))) return;
      const id = e.key === 'ArrowLeft' ? 'nav-prev' : e.key === 'ArrowRight' ? 'nav-next' : e.key === 'Home' ? 'nav-home' : null;
      const a = id && document.getElementById(id); if (a) { e.preventDefault(); a.click(); }
    });
    if (pid === 'index') return Journey.bootIndex(vis2);
    const s = sections[idx];
    const panel = document.getElementById('chart');
    Journey.mountChart(panel, s, idx);
    Kit.ready.then(() => Kit.fitAll(document));
  };

  /* ---------- index: journey map ---------- */
  Journey.bootIndex = function (visited) {
    const map = document.querySelector('.map'), wrap = document.querySelector('.mapwrap');
    document.querySelectorAll('.stop').forEach(li => li.classList.toggle('visited', visited.indexOf(li.dataset.id) >= 0));
    if (location.hash === '#done') { const b = document.querySelector('.donebanner'); if (b) b.classList.add('show'); }
    const svg = Kit.s('svg', { class: 'mapsvg' }); wrap.insertBefore(svg, map);
    const draw = () => {
      svg.textContent = '';
      const wr = wrap.getBoundingClientRect(), pts = [...document.querySelectorAll('.stop a')].map(b => { const r = b.getBoundingClientRect(); return { x: r.left + r.width / 2 - wr.left, y: r.top + r.height / 2 - wr.top }; });
      for (let i = 1; i < pts.length; i++) {
        const a = pts[i - 1], b = pts[i], vertical = Math.abs(b.y - a.y) > Math.abs(b.x - a.x) * 1.5;
        const d = vertical ? `M${a.x} ${a.y} C${a.x} ${(a.y + b.y) / 2} ${b.x} ${(a.y + b.y) / 2} ${b.x} ${b.y}` : `M${a.x} ${a.y} C${(a.x + b.x) / 2} ${a.y - 30} ${(a.x + b.x) / 2} ${b.y + 30} ${b.x} ${b.y}`;
        svg.appendChild(Kit.s('path', { d }));
      }
    };
    Kit.ready.then(() => { draw(); window.__kitReady = true; });
    window.addEventListener('resize', () => requestAnimationFrame(draw));
  };

  document.addEventListener('DOMContentLoaded', () => { try { Journey.boot(); } catch (e) { console.error(e); } });
})();

/* ===== bg.js ===== */
/* Alien Journey — animated space backgrounds (original work).
   Bg.mount(el, theme, seedIndex)   themes: starfield | cosmos | nebula | blackhole | asteroids | moonbase
   Canvas (stars, rocks, spiralling stars) + CSS clouds + inline SVG (black hole, moon base) + roaming character sprites.
   ~30 fps, pauses when the tab is hidden, static when prefers-reduced-motion. */
(function () {
  'use strict';
  const THEMES = ['starfield', 'cosmos', 'nebula', 'blackhole', 'asteroids', 'moonbase'];
  const FLOATERS = {
    starfield: [['ufo_pink', 78, 9, 70], ['space_dog', 70, 62, 95]],
    cosmos: [['ufo', 90, 14, 80], ['blob_buddy', 64, 72, 110], ['tentacle_buddy', 60, 40, 130]],
    nebula: [['ufo_pink', 80, 20, 75], ['alien_green', 52, 66, 100]],
    blackhole: [['robot_buddy', 56, 18, 120], ['ufo', 70, 74, 90]],
    asteroids: [['space_dog', 72, 12, 85], ['ufo_pink', 70, 66, 70]],
    moonbase: [['ufo', 84, 10, 75], ['cat_wave', 60, 32, 140]]
  };
  const SVGNS = 'http://www.w3.org/2000/svg';
  const S = (t, a, k) => { const e = document.createElementNS(SVGNS, t); for (const x in a || {}) e.setAttribute(x, a[x]); (k || []).forEach(c => e.appendChild(c)); return e; };
  const rng = seed => { let s = (seed >>> 0) || 1; return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296); };

  function blackholeSVG() {
    const svg = S('svg', { class: 'bh-svg', viewBox: '-300 -200 600 400' });
    const defs = S('defs'), rg = S('radialGradient', { id: 'bhglow' }), lg = S('linearGradient', { id: 'bhdisk', x1: 0, y1: 0, x2: 1, y2: 0 });
    [['0', '#000'], ['.55', '#000'], ['.7', '#6a2cff55'], ['1', '#00000000']].forEach(([o, c]) => rg.appendChild(S('stop', { offset: o, 'stop-color': c })));
    [['0', '#ff4fa0'], ['.35', '#ffb347'], ['.6', '#fff3a8'], ['1', '#7a4bff']].forEach(([o, c]) => lg.appendChild(S('stop', { offset: o, 'stop-color': c })));
    defs.append(rg, lg); svg.appendChild(defs);
    svg.appendChild(S('circle', { r: 190, fill: 'url(#bhglow)' }));
    const g = S('g', { transform: 'rotate(-18)' }), disk = S('g', { class: 'bh-disk-flat' });
    [[230, 52, 14, .5], [200, 44, 10, .75], [168, 36, 8, .95]].forEach(([rx, ry, sw, op]) => disk.appendChild(S('ellipse', { rx, ry, fill: 'none', stroke: 'url(#bhdisk)', 'stroke-width': sw, opacity: op, 'stroke-dasharray': '120 18 40 24', style: 'animation:march 6s linear infinite' })));
    g.appendChild(disk); svg.appendChild(g);
    svg.appendChild(S('circle', { r: 74, fill: '#000', stroke: '#ffcf70', 'stroke-width': 3, opacity: 1 }));
    svg.appendChild(S('path', { d: 'M-230 0 A230 52 0 0 0 230 0', transform: 'rotate(-18)', fill: 'none', stroke: 'url(#bhdisk)', 'stroke-width': 12, opacity: .9, 'stroke-linecap': 'round' }));
    return svg;
  }
  function moonSVG() {
    const svg = S('svg', { class: 'moon-svg', viewBox: '0 0 1200 300', preserveAspectRatio: 'xMidYMax slice' });
    svg.appendChild(S('circle', { cx: 960, cy: 70, r: 46, fill: '#59d7ff', stroke: '#17123a', 'stroke-width': 5 }));
    svg.appendChild(S('path', { d: 'M930 55 q20 -20 40 -6 q10 14 -8 24 q-24 8 -32 -18z M980 96 q16 -10 30 4 q-6 14 -24 10z', fill: '#5ef0c8' }));
    svg.appendChild(S('path', { d: 'M0 230 Q150 170 320 215 T640 205 T960 210 T1200 190 L1200 300 L0 300Z', fill: '#8a82d6', stroke: '#17123a', 'stroke-width': 5 }));
    svg.appendChild(S('path', { d: 'M0 262 Q200 225 420 255 T820 250 T1200 240 L1200 300 L0 300Z', fill: '#6c63c4', stroke: '#17123a', 'stroke-width': 5 }));
    [[170, 262, 34, 10], [530, 270, 26, 8], [880, 268, 40, 11], [1090, 262, 22, 7]].forEach(([x, y, rx, ry]) => svg.appendChild(S('ellipse', { cx: x, cy: y, rx, ry, fill: '#574fb0', stroke: '#17123a', 'stroke-width': 3 })));
    const dome = (x, y, s) => { const g = S('g', { transform: `translate(${x} ${y}) scale(${s})` }); g.appendChild(S('rect', { x: -60, y: -14, width: 120, height: 26, rx: 6, fill: '#d9d4ff', stroke: '#17123a', 'stroke-width': 5 })); g.appendChild(S('path', { d: 'M-48 -14 A48 48 0 0 1 48 -14Z', fill: '#59d7ff', stroke: '#17123a', 'stroke-width': 5, opacity: .9 })); [-30, 0, 30].forEach(wx => g.appendChild(S('rect', { x: wx - 7, y: -6, width: 14, height: 12, rx: 3, fill: '#ffd93b' }))); g.appendChild(S('path', { d: 'M0 -62 V-92 M0 -92 l16 6', stroke: '#17123a', 'stroke-width': 5, fill: 'none' })); g.appendChild(S('circle', { cx: 0, cy: -94, r: 6, fill: '#ff5fa8', stroke: '#17123a', 'stroke-width': 3 })); return g; };
    svg.append(dome(260, 222, 1), dome(760, 212, .8));
    svg.appendChild(S('path', { d: 'M1010 212 V150', stroke: '#17123a', 'stroke-width': 5 })); svg.appendChild(S('path', { d: 'M1010 150 h44 v28 h-44z', fill: '#ff5fa8', stroke: '#17123a', 'stroke-width': 4 }));
    return svg;
  }

  function mount(el, theme, seedIdx) {
    if (THEMES.indexOf(theme) < 0) theme = 'starfield';
    el.textContent = ''; el.className = 't-' + theme; el.dataset.theme = theme;
    const R = rng(1000 + (seedIdx || 0) * 77 + theme.length);
    const reduced = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
    // CSS / SVG layers
    if (theme === 'nebula') [['#ff4fa0', 46, 40, 55], ['#59d7ff', 70, 62, 45], ['#8a5cf0', 22, 70, 60], ['#5ef0c8', 80, 20, 35]].forEach(([c, x, y, s], i) => { const d = document.createElement('div'); d.className = 'cloud'; d.style.cssText = `left:${x - s / 2}%;top:${y - s / 2}%;width:${s}vw;height:${s * .8}vw;background:${c};animation-delay:${-i * 6}s`; el.appendChild(d); });
    if (theme === 'blackhole') el.appendChild(blackholeSVG());
    if (theme === 'moonbase') el.appendChild(moonSVG());
    const cv = document.createElement('canvas'); el.appendChild(cv);
    const ctx = cv.getContext('2d');
    let W = 0, H = 0, dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    const stars = [], rocks = [], shoot = { on: false, x: 0, y: 0, v: 0, life: 0 };
    const nStars = theme === 'cosmos' ? 220 : theme === 'asteroids' ? 90 : theme === 'blackhole' ? 150 : theme === 'nebula' ? 110 : 150;
    function resize() {
      W = el.clientWidth; H = el.clientHeight; cv.width = W * dpr; cv.height = H * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      stars.length = 0;
      for (let i = 0; i < nStars; i++) stars.push({ x: R() * W, y: R() * H, r: .5 + R() * 1.8, z: .2 + R() * .8, ph: R() * 6.28, sp: .5 + R() * 2, c: R() < .15 ? '#ffd93b' : R() < .3 ? '#5ef0c8' : '#ffffff', a: R() * 6.28, d: 40 + R() * Math.max(W, H) * .6 });
      rocks.length = 0;
      if (theme === 'asteroids') for (let i = 0; i < 16; i++) { const s = 14 + R() * 46, n = 7 + (R() * 3 | 0), pts = []; for (let k = 0; k < n; k++) { const a = k / n * 6.283, rr = s * (.75 + R() * .35); pts.push([Math.cos(a) * rr, Math.sin(a) * rr]); } rocks.push({ x: R() * W, y: R() * H, s, pts, rot: R() * 6.28, vr: (R() - .5) * .01, vx: -(.15 + R() * .5) * (s / 30), vy: .05 + R() * .2, c: ['#9a7bd6', '#c28b6a', '#7e86d6', '#b36ba1'][R() * 4 | 0], cr: [[.3, .2, .3], [-.35, -.1, .2]] }); }
    }
    function drawRock(r) {
      ctx.save(); ctx.translate(r.x, r.y); ctx.rotate(r.rot);
      ctx.beginPath(); r.pts.forEach((p, i) => i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1])); ctx.closePath();
      ctx.fillStyle = r.c; ctx.fill(); ctx.lineWidth = 4; ctx.strokeStyle = '#17123a'; ctx.stroke();
      ctx.fillStyle = 'rgba(23,18,58,.28)'; r.cr.forEach(c => { ctx.beginPath(); ctx.arc(c[0] * r.s, c[1] * r.s, r.s * .16, 0, 6.283); ctx.fill(); });
      ctx.restore();
    }
    function drawStar(s, t) {
      const tw = .55 + .45 * Math.sin(t * s.sp + s.ph);
      ctx.globalAlpha = tw; ctx.fillStyle = s.c;
      if (s.r > 1.6) { ctx.beginPath(); const r = s.r * 2.2; ctx.moveTo(s.x, s.y - r); ctx.lineTo(s.x + r * .28, s.y - r * .28); ctx.lineTo(s.x + r, s.y); ctx.lineTo(s.x + r * .28, s.y + r * .28); ctx.lineTo(s.x, s.y + r); ctx.lineTo(s.x - r * .28, s.y + r * .28); ctx.lineTo(s.x - r, s.y); ctx.lineTo(s.x - r * .28, s.y - r * .28); ctx.closePath(); ctx.fill(); }
      else { ctx.beginPath(); ctx.arc(s.x, s.y, s.r, 0, 6.283); ctx.fill(); }
    }
    let t = 0, last = 0, raf = 0;
    function frame(now) {
      raf = requestAnimationFrame(frame);
      if (document.hidden || now - last < 33) return; last = now; t += .033;
      ctx.clearRect(0, 0, W, H);
      if (theme === 'blackhole') {
        const cx = W * .78, cy = H * .5;
        stars.forEach(s => { s.a += .004 / Math.max(.3, s.d / 300); s.d -= .35 * s.z; if (s.d < 70) { s.d = Math.max(W, H) * .7; s.a = R() * 6.28; } s.x = cx + Math.cos(s.a) * s.d * 1.35; s.y = cy + Math.sin(s.a) * s.d * .8; drawStar(s, t); });
      } else {
        const drift = theme === 'cosmos' ? .25 : theme === 'asteroids' ? .1 : .05;
        stars.forEach(s => { s.x -= drift * s.z; if (s.x < -4) s.x = W + 4; drawStar(s, t); });
      }
      ctx.globalAlpha = 1;
      if (theme === 'cosmos') { // slow spinning galaxy
        const gx = W * .74, gy = H * .3; ctx.save(); ctx.translate(gx, gy); ctx.rotate(t * .05); ctx.scale(1, .45);
        for (let arm = 0; arm < 2; arm++) for (let i = 0; i < 90; i++) { const a = i * .13 + arm * 3.14, r = 6 + i * 2.1; ctx.globalAlpha = .75 * (1 - i / 95); ctx.fillStyle = i % 3 ? '#b9a4ff' : '#ff9fd0'; ctx.beginPath(); ctx.arc(Math.cos(a) * r, Math.sin(a) * r, 2 + (1 - i / 90) * 2, 0, 6.283); ctx.fill(); }
        ctx.globalAlpha = .9; ctx.fillStyle = '#fff3a8'; ctx.beginPath(); ctx.arc(0, 0, 10, 0, 6.283); ctx.fill(); ctx.restore(); ctx.globalAlpha = 1;
      }
      if (theme === 'asteroids') rocks.forEach(r => { r.x += r.vx; r.y += r.vy; r.rot += r.vr; if (r.x < -80) { r.x = W + 80; r.y = R() * H; } if (r.y > H + 80) r.y = -80; drawRock(r); });
      if (theme === 'starfield' || theme === 'moonbase' || theme === 'nebula') { // occasional shooting star
        if (!shoot.on && R() < .006) { shoot.on = true; shoot.x = R() * W * .8 + W * .2; shoot.y = R() * H * .4; shoot.v = 9 + R() * 6; shoot.life = 1; }
        if (shoot.on) { ctx.strokeStyle = `rgba(255,255,255,${shoot.life})`; ctx.lineWidth = 3; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(shoot.x, shoot.y); ctx.lineTo(shoot.x + shoot.v * 5, shoot.y - shoot.v * 2.2); ctx.stroke(); shoot.x -= shoot.v; shoot.y += shoot.v * .45; shoot.life -= .03; if (shoot.life <= 0) shoot.on = false; }
      }
    }
    resize(); window.addEventListener('resize', () => { resize(); if (reduced) frame(1e6); });
    if (reduced) { frame(1e6); cancelAnimationFrame(raf); } else raf = requestAnimationFrame(frame);
    // roaming characters (behind content; purely decorative)
    if (!reduced) (FLOATERS[theme] || []).forEach(([name, w, y, dur], i) => {
      const f = document.createElement('div'); f.className = 'floater'; f.setAttribute('aria-hidden', 'true');
      const img = new Image(); img.alt = ''; img.src = ((window.JOURNEY && JOURNEY.assets) || 'assets/') + 'sprites/' + name + '.webp'; f.appendChild(img);
      f.style.cssText = `width:${w}px;--y:${y}vh;--dy:${(R() * 16 - 8).toFixed(0)}vh;animation:${i % 2 ? 'flyL' : 'fly'} ${dur}s linear infinite;animation-delay:${-R() * dur}s`;
      el.appendChild(f);
    });
  }
  window.Bg = { mount, THEMES };
})();

/* ===== charts/checklist.js ===== */
/* checklist — data: {items:[{text, detail?, icon?}], intro?, done?}   3-8 tasks; rocket flies as you tick them. */
Journey.register('checklist', function (ctx) {
  const d = ctx.data, I = d.items, n = I.length, stage = ctx.stage;
  const root = Kit.h('div', 'ck'); stage.appendChild(root);
  const bar = Kit.h('div', 'ck-bar'), fill = Kit.h('div', 'ck-fill'), rocket = Kit.h('div', 'ck-rocket'), pct = Kit.fb('ck-pct', '0%', { min: 11, max: 16, nowrap: true });
  rocket.appendChild(Kit.sprite('ufo_pink')); bar.append(fill, rocket, pct); root.appendChild(bar);
  const list = Kit.h('div', 'ck-list'); root.appendChild(list);
  const state = new Array(n).fill(false);
  const rows = I.map((it, i) => {
    const r = Kit.h('div', 'card ck-item', { role: 'checkbox', 'aria-checked': 'false', tabindex: 0 });
    r.append(Kit.h('div', 'ck-box', null, ['']), Kit.h('div', 'ck-ic', null, [it.icon || '📌']), Kit.fb('ck-txt', it.text, { min: 11, max: 17, left: true }));
    r.addEventListener('click', () => toggle(i)); r.addEventListener('keydown', k => { if (k.key === 'Enter' || k.key === ' ') { k.preventDefault(); toggle(i); } });
    list.appendChild(r); return r;
  });
  const cheer = Kit.sprite('cat_cheer', 'ck-cheer'); const conf = Kit.h('div', 'ck-conf'); stage.append(cheer, conf);
  function paint() {
    const k = state.filter(Boolean).length, p = k / n;
    rows.forEach((r, i) => { r.classList.toggle('done', state[i]); r.setAttribute('aria-checked', state[i]); r.firstChild.textContent = state[i] ? '✓' : ''; });
    fill.style.width = p * 100 + '%'; rocket.style.left = Math.max(4, p * 100) + '%'; Kit.setText(pct, Math.round(p * 100) + '%');
    cheer.classList.toggle('show', k === n); ctx.enable('next', k < n); ctx.enable('all', k < n);
    if (k === n) { confetti(); }
    return k;
  }
  function confetti() { conf.textContent = ''; const r = Kit.rng(9); for (let i = 0; i < 28; i++) conf.appendChild(Kit.h('i', '', { style: `left:${r() * 100}%;background:${['#ffd93b', '#ff5fa8', '#5ef0c8', '#59d7ff'][i % 4]};animation-delay:${r() * .6}s;border-radius:${r() < .5 ? '50%' : '2px'}` })); setTimeout(() => (conf.textContent = ''), 2400); }
  function toggle(i) { state[i] = !state[i]; const k = paint(); ctx.say(state[i] ? `✅ ${I[i].text}${I[i].detail ? ' —— ' + I[i].detail : ''}` : `⬜ 取消：${I[i].text}`); if (k === n) ctx.say('🎉 ' + (d.done || '全部完成！你已經走完呢份清單。')); }
  ctx.setButtons([
    { id: 'next', label: '✅ 完成下一項', cls: 'mint', on: () => { const i = state.indexOf(false); if (i >= 0) toggle(i); } },
    { id: 'all', label: '☑ 全部完成', cls: 'pink', on: () => { state.fill(true); paint(); ctx.say('🎉 ' + (d.done || '全部完成！')); } },
    { id: 'reset', label: '↺ 重置', cls: 'blue', on: () => { state.fill(false); paint(); ctx.say(d.intro || '逐項㩒一下，將完成嘅任務剔起，火箭就會飛得越遠。'); } }
  ]);
  paint(); ctx.say(d.intro || '逐項㩒一下，將完成嘅任務剔起，火箭就會飛得越遠。');
  return { layout(narrow) {
    const rh = narrow ? 64 : 52, gap = 8, top = 42 + 10 + 14; list.style.gridTemplateRows = `repeat(${n},${rh}px)`; list.style.gap = gap + 'px'; list.style.marginTop = '14px';
    ctx.height(top + n * (rh + gap) + 6); cheer.style.height = narrow ? '70px' : '92px';
  } };
});

/* ===== charts/comic.js ===== */
/* comic — data: {panels:[{title?, scene?:starfield|cosmos|nebula|blackhole|asteroids|moonbase, char?, char2?, speaker?:1|2, say, caption?}]}  3-6 panels */
Journey.register('comic', function (ctx) {
  const P = ctx.data.panels, n = P.length, stage = ctx.stage;
  const wrap = Kit.h('div', 'cm-wrap'), dots = Kit.h('div', 'cm-dots');
  stage.append(wrap, dots);
  let cur = 0, running = false, narrow = false, W = 700, panelEl = null, dir = 'r';
  const SC = { starfield: ['#352c9c', '#150f45'], cosmos: ['#271c70', '#090624'], nebula: ['#7a2f9c', '#241060'], blackhole: ['#2a1050', '#05020f'], asteroids: ['#4a3082', '#2a1c52'], moonbase: ['#12124a', '#4b4aa8'] };
  function sceneBg(name, i) {
    const c = SC[name] || SC.starfield, bg = Kit.h('div', 'cm-bg'); bg.style.background = `linear-gradient(180deg,${c[0]},${c[1]})`;
    const r = Kit.rng(31 + i * 17);
    for (let k = 0; k < 22; k++) { const s = 2 + r() * 4; bg.appendChild(Kit.h('i', '', { style: `position:absolute;left:${r() * 100}%;top:${r() * 100}%;width:${s}px;height:${s}px;border-radius:50%;background:${r() < .3 ? '#ffd93b' : '#fff'};opacity:${.4 + r() * .6};animation:twinkle ${2 + r() * 3}s ease-in-out ${r() * 3}s infinite` })); }
    const pl = Kit.PLANET_COLORS[(i + 2) % 8], pe = Kit.h('div', '', { style: 'position:absolute;right:-4%;bottom:12%;width:22%;aspect-ratio:1;animation:drift 9s ease-in-out infinite' }); const sv = Kit.planet(100, { c1: pl[0], c2: pl[1], ring: i % 2 === 0 }); sv.setAttribute('width', '100%'); sv.setAttribute('height', '100%'); pe.appendChild(sv); bg.appendChild(pe);
    if (name === 'moonbase') bg.appendChild(Kit.h('div', '', { style: 'position:absolute;left:-5%;right:-5%;bottom:-8%;height:22%;background:#8a82d6;border-top:5px solid #17123a;border-radius:50% 50% 0 0' }));
    if (name === 'blackhole') bg.appendChild(Kit.h('div', '', { style: 'position:absolute;left:8%;top:30%;width:26%;aspect-ratio:1;border-radius:50%;background:radial-gradient(circle,#000 38%,#ff9340 46%,#6a2cff 60%,transparent 70%);animation:spin 14s linear infinite' }));
    return bg;
  }
  function build(i, anim) {
    const p = P[i], el = Kit.h('div', 'cm-panel' + (anim ? ' in-' + dir : '')); el.appendChild(sceneBg(p.scene || ctx.section.background, i));
    const pw = el.clientWidth;
    const c1 = Kit.fixSprite(p.char) || Kit.pick(Kit.CAST, i), c2 = p.char2 ? Kit.fixSprite(p.char2) : null, two = !!c2;
    const T = (cls, txt, o, st) => { const b = Kit.fb(cls, txt, o); b.style.cssText += st; el.appendChild(b); return b; };
    T('cm-title', p.title || ctx.section.title, { min: 11, max: 20, left: true }, '');
    T('chip cm-num', `${i + 1}/${n}`, { min: 11, max: 15, nowrap: true }, '');
    const ch = (name, st) => { const im = Kit.sprite(name, 'cm-char'); im.style.cssText = st; el.appendChild(im); return im; };
    const sp2 = p.speaker === 2 && two;
    if (!narrow) {
      ch(c1, 'left:2%;bottom:3%;height:66%;max-width:26%'); if (two) ch(c2, 'right:2%;bottom:3%;height:66%;max-width:26%;transform:scaleX(-1)');
      const bl = two ? 31 : 33, bw = two ? 38 : 63;
      T('cm-bubble', p.say, { min: 12, max: 24 }, `left:${bl}%;top:19%;width:${bw}%;height:${p.caption ? 38 : 50}%`);
      const tail = Kit.h('div', 'cm-tail', { style: `left:${sp2 ? bl + bw - 6 : bl + 3}%;top:${p.caption ? 55 : 66}%;transform:rotate(${sp2 ? 45 : 135}deg)` }); tail.style.top = `calc(${19 + (p.caption ? 38 : 50)}% - 18px)`; tail.style.transform = `rotate(45deg)`; if (!sp2) { tail.style.left = bl + 2 + '%'; } el.appendChild(tail);
      if (p.caption) T('cm-cap', p.caption, { min: 11, max: 17, left: true }, `left:${two ? 31 : 33}%;right:3%;bottom:5%;height:22%;${two ? 'right:' + 31 + '%;' : ''}`);
    } else {
      ch(c1, 'left:2%;bottom:2%;height:36%;max-width:44%'); if (two) ch(c2, 'right:2%;bottom:2%;height:36%;max-width:44%;transform:scaleX(-1)');
      T('cm-bubble', p.say, { min: 12, max: 22 }, `left:4%;right:4%;top:17%;height:${p.caption ? 30 : 38}%`);
      const tail = Kit.h('div', 'cm-tail', { style: `left:${sp2 ? 72 : 22}%;top:calc(${17 + (p.caption ? 30 : 38)}% - 18px);transform:rotate(45deg)` }); el.appendChild(tail);
      if (p.caption) T('cm-cap', p.caption, { min: 11, max: 16, left: true }, 'left:4%;right:4%;top:50%;height:12%');
    }
    return el;
  }
  function size() { const w = Math.min(W, 780); return narrow ? { w: W, h: Math.round(W * 1.28) } : { w, h: Math.round(w * .52) }; }
  function render(anim) {
    const s = size(); wrap.textContent = ''; ctx.height(s.h + 48);
    panelEl = build(cur, anim); panelEl.style.width = s.w + 'px'; panelEl.style.height = s.h + 'px'; wrap.appendChild(panelEl); Kit.fitAll(panelEl);
    dots.querySelectorAll('button').forEach((b, i) => b.classList.toggle('on', i === cur));
    ctx.enable('prev', cur > 0); ctx.enable('next', cur < n - 1);
    ctx.say(`📖 第 ${cur + 1}/${n} 格：${P[cur].caption || P[cur].say}`);
    requestAnimationFrame(() => Kit.fitAll(panelEl));
  }
  for (let i = 0; i < n; i++) { const b = Kit.h('button', '', { type: 'button', 'aria-label': '第 ' + (i + 1) + ' 格' }); b.addEventListener('click', () => { dir = i >= cur ? 'r' : 'l'; cur = i; render(true); }); dots.appendChild(b); }
  const go = (i) => { dir = i >= cur ? 'r' : 'l'; cur = Kit.clamp(i, 0, n - 1); render(true); };
  async function play() {
    if (running) { running = false; ctx.label('play', '▶ 自動播放'); return; }
    running = true; ctx.label('play', '⏸ 暫停'); if (cur >= n - 1) go(0);
    while (running && cur < n - 1) { await Kit.sleep(2800); if (!running) break; go(cur + 1); }
    running = false; ctx.label('play', '▶ 自動播放');
  }
  ctx.setButtons([
    { id: 'prev', label: '⏮ 上一格', on: () => { running = false; go(cur - 1); } },
    { id: 'next', label: '⏭ 下一格', on: () => { running = false; go(cur + 1); } },
    { id: 'play', label: '▶ 自動播放', cls: 'mint', on: play },
    { id: 'reset', label: '↺ 由頭睇', cls: 'blue', on: () => { running = false; ctx.label('play', '▶ 自動播放'); go(0); } }
  ]);
  return { layout(nw, w) { narrow = nw; W = w; render(false); } };
});

/* ===== charts/compare.js ===== */
/* compare — data: {left:{title,char?}, right:{title,char?}, rows:[{label,a,b}], verdict?, intro?}   2-6 rows revealed one by one. */
Journey.register('compare', function (ctx) {
  const d = ctx.data, R = d.rows, n = R.length, stage = ctx.stage;
  const root = Kit.h('div', 'cp'); stage.appendChild(root);
  const side = (o, cls, fb) => Kit.h('div', 'cp-side ' + cls, null, [Kit.sprite(Kit.fixSprite(o.char) || fb), Kit.fb('', (o.icon ? o.icon + ' ' : '') + o.title, { min: 13, max: 24 })]);
  root.appendChild(Kit.h('div', 'cp-head', null, [side(d.left, 'a', 'alien_green'), Kit.h('div', 'cp-vs', null, ['VS']), side(d.right, 'b', 'blob_buddy')]));
  const rows = R.map((r, i) => {
    const el = Kit.h('div', 'cp-row hidden', { role: 'button', tabindex: 0 });
    el.append(Kit.h('div', 'cp-cell a', null, [Kit.fb('', r.a, { min: 10, max: 16, left: true })]), Kit.h('div', 'cp-mid', null, [Kit.fb('', r.label, { min: 10, max: 14, nowrap: false })]), Kit.h('div', 'cp-cell b', null, [Kit.fb('', r.b, { min: 10, max: 16, left: true })]));
    el.addEventListener('click', () => toggle(i)); el.addEventListener('keydown', k => { if (k.key === 'Enter' || k.key === ' ') { k.preventDefault(); toggle(i); } });
    root.appendChild(el); return el;
  });
  const verdict = Kit.fb('cp-verdict hidden', d.verdict || '', { min: 11, max: 18, left: true }); verdict.style.display = d.verdict ? 'flex' : 'none'; root.appendChild(verdict);
  const shown = new Array(n).fill(false); let running = false;
  function paint(hot) {
    rows.forEach((r, i) => { r.classList.toggle('hidden', !shown[i]); r.classList.toggle('hot', i === hot); });
    verdict.classList.toggle('hidden', !shown.every(Boolean)); ctx.enable('next', !shown.every(Boolean));
  }
  function toggle(i) { shown[i] = !shown[i]; paint(shown[i] ? i : -1); ctx.say(shown[i] ? `🔎 ${R[i].label}：${d.left.title}「${R[i].a}」 vs ${d.right.title}「${R[i].b}」` : '🙈 已收埋，再㩒一次可以睇返。'); }
  function next() { const i = shown.indexOf(false); if (i < 0) return; shown[i] = true; paint(i); ctx.say(`🔎 ${R[i].label}：${d.left.title}「${R[i].a}」 vs ${d.right.title}「${R[i].b}」`); if (shown.every(Boolean) && d.verdict) ctx.say('🏁 ' + d.verdict); }
  async function play() {
    if (running) { running = false; ctx.label('play', '▶ 逐行揭曉'); return; }
    running = true; ctx.label('play', '⏸ 暫停'); if (shown.every(Boolean)) { shown.fill(false); paint(-1); }
    while (running && shown.indexOf(false) >= 0) { next(); await Kit.sleep(1900); }
    running = false; ctx.label('play', '▶ 逐行揭曉');
  }
  ctx.setButtons([
    { id: 'play', label: '▶ 逐行揭曉', cls: 'mint', on: play },
    { id: 'next', label: '⏭ 下一項', on: () => { running = false; next(); } },
    { id: 'all', label: '👁 全部顯示', cls: 'pink', on: () => { running = false; shown.fill(true); paint(-1); ctx.say(d.verdict ? '🏁 ' + d.verdict : '👁 全部顯示晒。'); } },
    { id: 'reset', label: '↺ 重置', cls: 'blue', on: () => { running = false; shown.fill(false); paint(-1); ctx.label('play', '▶ 逐行揭曉'); ctx.say(d.intro || '㩒每一行，或者按「逐行揭曉」，睇兩邊有咩唔同。'); } }
  ]);
  paint(-1); ctx.say(d.intro || '㩒每一行，或者按「逐行揭曉」，睇兩邊有咩唔同。');
  return { layout(narrow, W) {
    const head = narrow ? 92 : 104, rh = narrow ? 112 : 54, gap = 8, vh = d.verdict ? (narrow ? 64 : 52) + gap : 0;
    root.querySelector('.cp-head').style.height = head + 'px';
    rows.forEach(r => { r.style.height = rh + 'px'; r.style.gridTemplateColumns = narrow ? 'minmax(0,1fr) minmax(0,1fr)' : 'minmax(0,1fr) 96px minmax(0,1fr)'; r.style.gridTemplateRows = narrow ? '28px minmax(0,1fr)' : '1fr';
      const [a, m, b] = r.children; if (narrow) { m.style.cssText = 'grid-column:1/3;grid-row:1'; a.style.cssText = 'grid-column:1;grid-row:2'; b.style.cssText = 'grid-column:2;grid-row:2'; } else { m.style.cssText = ''; a.style.cssText = ''; b.style.cssText = ''; } });
    verdict.style.height = (narrow ? 64 : 52) + 'px'; verdict.style.marginTop = 'auto';
    ctx.height(head + gap + n * (rh + gap) + vh + 4); } };
});

/* ===== charts/cycle.js ===== */
/* cycle — data: {center?:{text,char}, stages:[{title,text,icon?}], intro?}   3-8 stages. UFO orbits the ring. */
Journey.register('cycle', function (ctx) {
  const d = ctx.data, S = d.stages, n = S.length, stage = ctx.stage;
  const ring = Kit.h('div', 'cy-ring'), hub = Kit.h('div', 'cy-hub'), ufo = Kit.h('div', 'cy-ufo');
  const hubImg = Kit.sprite(Kit.fixSprite((d.center || {}).char) || ctx.mascot); hub.appendChild(hubImg); ufo.appendChild(Kit.sprite('ufo'));
  const planets = S.map((s, i) => {
    const b = Kit.h('button', 'cy-planet', { type: 'button', 'aria-label': (i + 1) + '. ' + s.title });
    const col = Kit.PLANET_COLORS[i % 8]; b.appendChild(Kit.planet(80, { c1: col[0], c2: col[1], ring: i % 4 === 1 }));
    b.append(Kit.h('span', 'ic', null, [s.icon || '🪐']), Kit.h('span', 'no', null, [String(i + 1)]));
    b.addEventListener('click', () => { running = false; ctx.label('play', '▶ 播放'); goto(i); }); return b;
  });
  const hubText = Kit.fb('', (d.center || {}).text || '', { min: 10, max: 14 }); hubText.style.cssText = 'position:absolute;left:12%;right:12%;bottom:8%;height:26%;color:#fff;font-weight:700';
  hub.appendChild(hubText);
  const card = Kit.h('div', 'card cy-card');
  const tag = Kit.fb('chip', '', { min: 10, max: 13, nowrap: true }); tag.style.cssText = 'width:130px;height:26px';
  const ttl = Kit.fb('', '', { min: 13, max: 22, left: true }), txt = Kit.fb('', '', { min: 11, max: 16, left: true }), nxt = Kit.fb('', '', { min: 10, max: 13, left: true });
  ttl.style.fontWeight = '700'; txt.style.color = '#3b3470'; nxt.style.color = '#6a63a8';
  card.append(tag, ttl, txt, nxt);
  const legend = Kit.h('div', 'cy-legend'), legs = S.map((s, i) => { const l = Kit.fb('cy-leg', (i + 1) + ' ' + (s.icon || '') + ' ' + s.title, { min: 10, max: 14, left: true }, { role: 'button', tabindex: 0 }); l.addEventListener('click', () => { running = false; goto(i); }); l.addEventListener('keydown', k => { if (k.key === 'Enter') goto(i); }); legend.appendChild(l); return l; });
  stage.append(ring, hub, ...planets, ufo, card, legend);
  let cur = 0, dir = 1, running = false, geo = null, ang = 0, tw = null;
  const angOf = i => -Math.PI / 2 + dir * i * 2 * Math.PI / n;
  function place() {
    const g = geo; if (!g) return;
    planets.forEach((p, i) => { const a = angOf(i); p.style.left = g.cx + Math.cos(a) * g.R + 'px'; p.style.top = g.cy + Math.sin(a) * g.R + 'px'; });
    setUfo(ang);
  }
  function setUfo(a) { const g = geo; ufo.style.left = g.cx + Math.cos(a) * g.R * 1.0 + 'px'; ufo.style.top = g.cy + Math.sin(a) * g.R * 1.0 - 38 + 'px'; }
  function layout(narrow, W) {
    let S0, H, cardBox, legBox;
    if (!narrow) { H = 440; S0 = Math.min(H, W * .5); const x0 = S0 + 24; cardBox = { l: x0, t: 4, w: W - x0, h: 250 }; legBox = { l: x0, t: 264, w: W - x0, h: Math.ceil(n / 2) * 36 }; }
    else { S0 = Math.min(W, 340); cardBox = { l: 0, t: S0 + 10, w: W, h: 196 }; legBox = { l: 0, t: S0 + 216, w: W, h: Math.ceil(n / 2) * 36 }; H = legBox.t + legBox.h + 6; }
    const psz = n <= 5 ? 74 : 62, R = S0 / 2 - psz / 2 - 6, cx = S0 / 2, cy = (narrow ? S0 / 2 : H / 2);
    geo = { cx, cy, R };
    ctx.height(H);
    Object.assign(ring.style, { left: cx - R + 'px', top: cy - R + 'px', width: 2 * R + 'px', height: 2 * R + 'px' });
    const hs = Math.max(90, R * 1.05); Object.assign(hub.style, { left: cx + 'px', top: cy + 'px', width: hs + 'px', height: hs + 'px' });
    planets.forEach(p => { p.style.width = p.style.height = psz + 'px'; });
    Object.assign(card.style, { left: cardBox.l + 'px', top: cardBox.t + 'px', width: cardBox.w + 'px', height: cardBox.h + 'px' });
    Object.assign(legend.style, { left: legBox.l + 'px', top: legBox.t + 'px', width: legBox.w + 'px', height: legBox.h + 'px' });
    ang = angOf(cur); place();
  }
  function paint() {
    const s = S[cur];
    planets.forEach((p, i) => p.classList.toggle('active', i === cur)); legs.forEach((l, i) => l.classList.toggle('on', i === cur));
    Kit.setText(tag, `第 ${cur + 1} / ${n} 階段`); Kit.setText(ttl, (s.icon || '') + ' ' + s.title); Kit.setText(txt, s.text || '');
    const nx = S[(cur + dir + n) % n]; Kit.setText(nxt, '➡ 下一個：' + nx.title);
    ctx.say(`🪐 ${cur + 1}/${n} ${s.title}：${s.text || ''}`);
  }
  function goto(i) {
    const from = ang; cur = ((i % n) + n) % n; const to = angOf(cur); let delta = to - from;
    // travel in the current direction
    if (dir > 0) while (delta < 0) delta += 2 * Math.PI; else while (delta > 0) delta -= 2 * Math.PI;
    if (Math.abs(delta) > 2 * Math.PI - .001) delta = 0;
    paint(); if (tw) tw.cancel();
    tw = Kit.tween(800, t => { ang = from + delta * t; setUfo(ang); }); tw.done.then(ok => { if (ok) ang = to; });
  }
  async function play() {
    if (running) { running = false; ctx.label('play', '▶ 播放'); return; }
    running = true; ctx.label('play', '⏸ 暫停');
    for (let k = 0; k < n && running; k++) { goto(cur + dir); await Kit.sleep(2200); }
    running = false; ctx.label('play', '▶ 播放');
  }
  ctx.setButtons([
    { id: 'prev', label: '⏮ 上一個', on: () => { running = false; goto(cur - dir); } },
    { id: 'play', label: '▶ 播放', cls: 'mint', on: play },
    { id: 'next', label: '⏭ 下一個', on: () => { running = false; goto(cur + dir); } },
    { id: 'dir', label: '🔄 順時針', cls: 'orange', on: () => { dir = -dir; ctx.label('dir', dir > 0 ? '🔄 順時針' : '🔄 逆時針'); ang = angOf(cur); place(); paint(); } }
  ]);
  paint();
  return { layout };
});

/* ===== charts/flashcards.js ===== */
/* flashcards — data: {cards:[{front, back, icon?}], intro?}   3-10 cards; tap card to flip. */
Journey.register('flashcards', function (ctx) {
  const d = ctx.data, C = d.cards, n = C.length, stage = ctx.stage;
  const root = Kit.h('div', 'fl'); stage.appendChild(root);
  const count = Kit.fb('chip fl-count', '', { min: 11, max: 14, nowrap: true }); stage.appendChild(count);
  const card = Kit.h('div', 'fl-card', { role: 'button', tabindex: 0, 'aria-label': 'flip card' }), inner = Kit.h('div', 'fl-in');
  const mk = (cls) => { const f = Kit.h('div', 'card fl-face ' + cls); const ic = Kit.h('div', 'ic'), t = Kit.fb('', '', { min: 13, max: cls === 'back' ? 24 : 34 }); f.append(ic, t); return { f, ic, t }; };
  const F = mk('front'), B = mk('back'); inner.append(F.f, B.f); card.appendChild(inner); root.appendChild(card);
  const hint = Kit.fb('fl-hint', '👆 點擊卡片翻面', { min: 11, max: 14 }); hint.style.width = '240px'; root.appendChild(hint);
  const peekL = Kit.sprite(Kit.fixSprite(d.peek) || 'alien_green', 'fl-peek'), peekR = Kit.sprite('space_dog', 'fl-peek'); peekL.style.left = '0'; peekR.style.right = '0'; peekR.style.transform = 'scaleX(-1)'; stage.append(peekL, peekR);
  let cur = 0, flip = false;
  function show(i, say) {
    cur = Kit.clamp(i, 0, n - 1); flip = false; card.classList.remove('flip');
    F.ic.textContent = C[cur].icon || '💡'; B.ic.textContent = '✨'; Kit.setText(F.t, C[cur].front); Kit.setText(B.t, C[cur].back); Kit.setText(count, `🃏 ${cur + 1} / ${n}`);
    ctx.enable('prev', cur > 0); ctx.enable('next', cur < n - 1); if (say !== false) ctx.say(`🃏 ${cur + 1}/${n}：${C[cur].front}（㩒卡片睇答案）`);
    Kit.fitAll(card);
  }
  function doFlip() { flip = !flip; card.classList.toggle('flip', flip); ctx.say(flip ? `✨ ${C[cur].front} → ${C[cur].back}` : `🃏 ${C[cur].front}`); }
  card.addEventListener('click', doFlip); card.addEventListener('keydown', k => { if (k.key === 'Enter' || k.key === ' ') { k.preventDefault(); doFlip(); } });
  ctx.setButtons([
    { id: 'prev', label: '⏮ 上一張', on: () => show(cur - 1) },
    { id: 'flip', label: '🔄 翻面', cls: 'mint', on: doFlip },
    { id: 'next', label: '⏭ 下一張', on: () => show(cur + 1) },
    { id: 'reset', label: '↺ 由頭', cls: 'blue', on: () => show(0) }
  ]);
  show(0, false); ctx.say(d.intro || '㩒卡片翻面，睇睇背面嘅答案。');
  return { layout(narrow, W) {
    const cw = Math.min(W - (narrow ? 8 : 40), 640), ch = narrow ? 270 : 290; ctx.height(narrow ? 400 : 440);
    card.style.width = cw + 'px'; card.style.height = ch + 'px'; card.style.marginTop = '40px';
    peekL.style.width = peekR.style.width = narrow ? '58px' : '96px'; Kit.fitAll(card);
  } };
});

/* ===== charts/flowchart.js ===== */
/* flowchart — data: {start, nodes:[{id,type:start|step|decision|end,text,note?,next | yes,no,yesLabel?,noLabel?}], mascot?}
   Auto-layout: ranks (longest path, back-edges ignored) x lanes. Horizontal when <=5 ranks and wide, else vertical. */
Journey.register('flowchart', function (ctx) {
  const d = ctx.data, nodes = d.nodes, byId = {};
  nodes.forEach((n, i) => { n.type = n.type || (n.yes ? 'decision' : i === 0 ? 'start' : !n.next ? 'end' : 'step'); byId[n.id] = n; });
  const outs = n => n.type === 'decision' ? [{ to: n.yes, k: 'yes', label: n.yesLabel || '是' }, { to: n.no, k: 'no', label: n.noLabel || '否' }] : n.next ? [{ to: n.next, k: 'next' }] : [];
  const st = {}, back = new Set(), post = [];
  (function dfs(id) { st[id] = 1; outs(byId[id]).forEach(e => { if (st[e.to] === 1) back.add(id + '>' + e.to); else if (!st[e.to]) dfs(e.to); }); st[id] = 2; post.push(id); })(d.start);
  const topo = post.slice().reverse(), rank = {}; topo.forEach(id => (rank[id] = 0));
  topo.forEach(id => outs(byId[id]).forEach(e => { if (!back.has(id + '>' + e.to)) rank[e.to] = Math.max(rank[e.to], rank[id] + 1); }));
  topo.sort((a, b) => rank[a] - rank[b]);
  const lane = {}, occ = {}, pref = {}; pref[d.start] = 0;
  topo.forEach(id => {
    const p = pref[id] == null ? 0 : pref[id]; let l = p;
    for (const o of [0, 1, -1, 2, -2, 3, -3]) if (!occ[rank[id] + ',' + (p + o)]) { l = p + o; break; }
    lane[id] = l; occ[rank[id] + ',' + l] = 1;
    const n = byId[id];
    if (n.type === 'decision') { if (pref[n.yes] == null) pref[n.yes] = l; if (pref[n.no] == null && !back.has(id + '>' + n.no)) pref[n.no] = l + 1; }
    else if (n.next && pref[n.next] == null) pref[n.next] = l;
  });
  const minL = Math.min(...topo.map(i => lane[i])); topo.forEach(i => (lane[i] -= minL));
  const maxR = Math.max(...topo.map(i => rank[i])), maxL = Math.max(...topo.map(i => lane[i]));
  const hasBack = back.size > 0;

  const stage = ctx.stage, svg = Kit.s('svg', { class: 'fc-svg' }); stage.appendChild(svg);
  const defs = Kit.s('defs'); [['fca', '#cfc9ff'], ['fch', '#ffd93b']].forEach(([id, c]) => { const m = Kit.s('marker', { id: id + '-' + ctx.index, viewBox: '0 0 10 10', refX: 8, refY: 5, markerWidth: 5.5, markerHeight: 5.5, orient: 'auto-start-reverse', markerUnits: 'strokeWidth' }); m.appendChild(Kit.s('path', { class: 'arrow', d: 'M0 0 L10 5 L0 10z', fill: c })); defs.appendChild(m); }); svg.appendChild(defs);
  const num = {}; topo.forEach((id, i) => (num[id] = i + 1));
  const els = {};
  topo.forEach(id => {
    const n = byId[id], e = Kit.h('div', 'fc-node ' + n.type, { tabindex: 0, role: 'button', 'aria-label': n.text });
    e.appendChild(Kit.h('span', 'fc-badge', null, [n.type === 'decision' ? '？' : String(num[id])]));
    e.appendChild(Kit.fb('fc-text', n.text, { min: 10, max: 17 }));
    const go = () => { if (running) return; show(id, false); };
    e.addEventListener('click', go); e.addEventListener('keydown', ev => { if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); go(); } });
    stage.appendChild(e); els[id] = e;
  });
  const edges = [];
  topo.forEach(id => outs(byId[id]).forEach(o => {
    const path = Kit.s('path', { 'marker-end': `url(#fca-${ctx.index})` }); svg.appendChild(path);
    const ed = { from: id, to: o.to, k: o.k, path, back: back.has(id + '>' + o.to) };
    if (o.k !== 'next') {
      ed.chip = Kit.h('button', 'fc-label ' + (o.k === 'no' ? 'no' : ''), { type: 'button', title: o.label }, [o.label]);
      ed.chip.addEventListener('click', e => { e.stopPropagation(); choice[id] = o.k; refreshChips(); ctx.say((byId[id].text || '') + ' → ' + o.label); });
      stage.appendChild(ed.chip);
    }
    edges.push(ed);
  }));
  const tok = Kit.h('div', 'fc-tok'); tok.appendChild(Kit.sprite(ctx.mascot)); tok.style.display = 'none'; stage.appendChild(tok);

  let box = {}, cur = null, running = false, alt = false, steps = 0, moveT = null; const choice = {}, done = new Set();
  const pick = id => choice[id] || (alt ? 'no' : 'yes');
  function refreshChips() { edges.forEach(e => { if (e.chip) e.chip.classList.toggle('chosen', pick(e.from) === e.k); }); }
  function layout(narrow, W) {
    const horiz = !narrow && maxR + 1 <= 5, nR = maxR + 1, nL = maxL + 1;
    let H;
    if (horiz) {
      H = 440; const padX = 16, padY = 26, back = hasBack ? 34 : 0, cw = (W - 2 * padX) / nR, rh = (H - 2 * padY - back) / nL;
      const w = Math.min(190, cw - 46), h = Math.min(104, rh - 38);
      topo.forEach(id => (box[id] = { cx: padX + cw * (rank[id] + .5), cy: padY + rh * (lane[id] + .5), w, h }));
    } else {
      const padX = 12, padY = 24, rowH = narrow ? 100 : 98, rightPad = hasBack ? 30 : 0, colW = (W - 2 * padX - rightPad) / nL;
      const w = Math.min(260, colW - (narrow ? 22 : 34)), h = narrow ? 70 : 74;
      H = padY * 2 + rowH * nR;
      topo.forEach(id => (box[id] = { cx: padX + colW * (lane[id] + .5), cy: padY + rowH * (rank[id] + .5), w, h }));
    }
    ctx.height(H); svg.setAttribute('width', W); svg.setAttribute('height', H);
    topo.forEach(id => { const b = box[id], e = els[id]; Object.assign(e.style, { left: b.cx - b.w / 2 + 'px', top: b.cy - b.h / 2 + 'px', width: b.w + 'px', height: b.h + 'px' }); });
    const bottomMost = Math.max(...topo.map(i => box[i].cy + box[i].h / 2)), rightMost = Math.max(...topo.map(i => box[i].cx + box[i].w / 2));
    let bk = 0;
    edges.forEach(ed => {
      const A = box[ed.from], B = box[ed.to], dec = byId[ed.from].type === 'decision';
      const L = o => ({ l: o.cx - o.w / 2, r: o.cx + o.w / 2, t: o.cy - o.h / 2, b: o.cy + o.h / 2 });
      const a = L(A), b = L(B); let p;
      if (horiz) {
        if (ed.back) { const y = bottomMost + 12 + 6 * bk++; p = `M${A.cx - 14} ${a.b} V${y} H${B.cx + 18} V${b.b}`; }
        else if (lane[ed.from] === lane[ed.to]) p = `M${a.r} ${A.cy} H${b.l}`;
        else if (rank[ed.from] === rank[ed.to]) p = `M${A.cx} ${lane[ed.to] > lane[ed.from] ? a.b : a.t} V${lane[ed.to] > lane[ed.from] ? b.t : b.b}`;
        else if (dec) p = `M${A.cx} ${lane[ed.to] > lane[ed.from] ? a.b : a.t} V${B.cy} H${b.l}`;
        else p = `M${a.r} ${A.cy} H${B.cx} V${lane[ed.to] > lane[ed.from] ? b.t : b.b}`;
      } else {
        if (ed.back) { const x = rightMost + 14 + 6 * bk++; p = `M${a.r} ${A.cy + 14} H${x} V${B.cy + 14} H${b.r}`; }
        else if (lane[ed.from] === lane[ed.to]) p = `M${A.cx} ${a.b} V${b.t}`;
        else if (rank[ed.from] === rank[ed.to]) p = `M${lane[ed.to] > lane[ed.from] ? a.r : a.l} ${A.cy} H${lane[ed.to] > lane[ed.from] ? b.l : b.r}`;
        else if (dec) p = `M${lane[ed.to] > lane[ed.from] ? a.r : a.l} ${A.cy} H${B.cx} V${b.t}`;
        else p = `M${A.cx} ${a.b} V${B.cy} H${lane[ed.to] > lane[ed.from] ? b.l : b.r}`;
      }
      ed.path.setAttribute('d', p); ed.pts = null;
      if (ed.chip) { const len = ed.path.getTotalLength(), pt = ed.path.getPointAtLength(Math.min(len * .5, 34)); ed.chip.style.left = pt.x + 'px'; ed.chip.style.top = pt.y + 'px'; }
    });
    refreshChips();
    if (cur) placeTok(cur);
  }
  function placeTok(id) { const b = box[id]; if (!b) return; tok.style.display = ''; tok.style.left = b.cx - 23 + 'px'; tok.style.top = b.cy - b.h / 2 - 34 + 'px'; }
  function show(id, animate) {
    if (!box[id]) return Promise.resolve();
    done.add(cur); cur = id;
    Object.keys(els).forEach(k => { els[k].classList.toggle('active', k === id); els[k].classList.toggle('done', done.has(k) && k !== id); });
    edges.forEach(e => { const hot = e.from === id; e.path.classList.toggle('hot', hot); e.path.setAttribute('marker-end', `url(#${hot ? 'fch' : 'fca'}-${ctx.index})`); });
    const n = byId[id]; ctx.say((n.type === 'decision' ? '❓ ' : n.type === 'end' ? '🏁 ' : '📍 ') + (n.note || n.text));
    ctx.enable('next', n.type !== 'end'); ctx.enable('play', n.type !== 'end');
    refreshChips(); placeTok(id); return Promise.resolve();
  }
  function walk(ed) { // token travels along the edge, then the node lights up
    return new Promise(res => {
      const pts = Kit.samplePath(ed.path, 28), tot = Kit.polyLen(pts);
      if (moveT) moveT.cancel();
      tok.style.display = '';
      moveT = Kit.tween(650, t => { const p = Kit.polyAt(pts, tot * t); tok.style.left = p.x - 23 + 'px'; tok.style.top = p.y - 34 + 'px'; });
      moveT.done.then(() => { show(ed.to, true); res(); });
    });
  }
  async function step() {
    if (!cur) { show(d.start); return; }
    const n = byId[cur]; if (n.type === 'end') return;
    const ed = edges.find(e => e.from === cur && (n.type !== 'decision' || e.k === pick(cur)));
    if (ed) { steps++; await walk(ed); }
  }
  async function play() {
    if (running) { running = false; ctx.label('play', '▶ 播放'); return; }
    running = true; ctx.label('play', '⏸ 暫停'); steps = 0;
    if (cur && byId[cur].type === 'end') reset();
    if (!cur) { show(d.start); await Kit.sleep(900); }
    while (running && byId[cur].type !== 'end' && steps < 24) { await step(); await Kit.sleep(900); }
    running = false; ctx.label('play', '▶ 播放');
  }
  function reset() { running = false; cur = null; done.clear(); tok.style.display = 'none'; Object.values(els).forEach(e => e.classList.remove('active', 'done')); edges.forEach(e => { e.path.classList.remove('hot'); e.path.setAttribute('marker-end', `url(#fca-${ctx.index})`); }); ctx.label('play', '▶ 播放'); ctx.enable('next', true); ctx.enable('play', true); ctx.say(d.intro || '按「播放」或「下一步」，跟住小角色行過每一步；遇到「？」可以㩒是／否選路線。'); placeTok(d.start); tok.style.display = 'none'; }
  ctx.setButtons([
    { id: 'play', label: '▶ 播放', cls: 'mint', on: play },
    { id: 'next', label: '⏭ 下一步', on: () => { if (!running) step(); } },
    { id: 'alt', label: '🔀 走「是」', cls: 'pink', on: () => { alt = !alt; ctx.label('alt', alt ? '🔀 走「否」' : '🔀 走「是」'); refreshChips(); ctx.say(alt ? '之後遇到「？」會行「否」路線。' : '之後遇到「？」會行「是」路線。'); } },
    { id: 'reset', label: '↺ 重來', cls: 'blue', on: reset }
  ]);
  reset();
  return { layout };
});

/* ===== charts/hotspots.js ===== */
/* hotspots — data: {scene:'planet'|'moonbase'|'space', spots:[{x,y (0-100 %), icon, title, text}], intro?}   3-6 clickable hotspots. */
Journey.register('hotspots', function (ctx) {
  const d = ctx.data, SP = d.spots, n = SP.length, stage = ctx.stage;
  const scene = Kit.h('div', 'hs-scene'), info = Kit.h('div', 'card hs-info');
  const iic = Kit.h('div', 'ic', null, ['🔍']), it = Kit.fb('t', '', { min: 13, max: 20, left: true }), id_ = Kit.fb('d', '', { min: 11, max: 16, left: true });
  info.append(iic, it, id_);
  const count = Kit.fb('chip hs-count', '', { min: 11, max: 14, nowrap: true });
  const tip = Kit.h('div', 'hs-tip'); const guide = Kit.h('div', 'hs-guide'); guide.appendChild(Kit.sprite(Kit.fixSprite(d.guide) || 'robot_buddy'));
  const R = Kit.rng(5), svg = Kit.s('svg', { viewBox: '0 0 160 100', preserveAspectRatio: 'xMidYMid slice' });
  const kind = d.scene || 'planet';
  const defs = Kit.s('defs'); const g1 = Kit.s('linearGradient', { id: 'hsb', x1: 0, y1: 0, x2: 0, y2: 1 });
  (kind === 'moonbase' ? [['0', '#06061f'], ['1', '#2b2a73']] : kind === 'space' ? [['0', '#1b1060'], ['1', '#09062a']] : [['0', '#0b0830'], ['1', '#27208a']]).forEach(([o, c]) => g1.appendChild(Kit.s('stop', { offset: o, 'stop-color': c }))); defs.appendChild(g1); svg.appendChild(defs);
  svg.appendChild(Kit.s('rect', { width: 160, height: 100, fill: 'url(#hsb)' }));
  for (let i = 0; i < 40; i++) svg.appendChild(Kit.s('circle', { cx: R() * 160, cy: R() * 70, r: .3 + R() * .7, fill: '#fff', opacity: .5 + R() * .5 }));
  const ink = { stroke: '#17123a', 'stroke-width': 1.2, 'stroke-linejoin': 'round' };
  if (kind === 'planet') {
    svg.appendChild(Kit.s('ellipse', Object.assign({ cx: 80, cy: 150, rx: 150, ry: 92, fill: '#3aa7e8' }, ink)));
    [['M30 70 q14 -8 26 2 q6 10 -8 14 q-18 2 -18 -16z', '#6fd36f'], ['M90 62 q18 -10 34 4 q4 14 -14 14 q-20 -2 -20 -18z', '#6fd36f'], ['M62 88 q12 -6 24 2 q-4 10 -20 8z', '#e8c76a']].forEach(([dd, f]) => svg.appendChild(Kit.s('path', Object.assign({ d: dd, fill: f }, ink))));
    svg.appendChild(Kit.s('path', Object.assign({ d: 'M104 42 q6 -8 14 -2 q8 -2 10 4 q-2 6 -12 6 h-10z', fill: '#fff' }, ink)));
    svg.appendChild(Kit.s('path', Object.assign({ d: 'M18 40 q8 -6 14 0 q8 -2 8 4 h-22z', fill: '#fff' }, ink)));
    svg.appendChild(Kit.s('circle', Object.assign({ cx: 140, cy: 20, r: 9, fill: '#ffd93b' }, ink)));
  } else if (kind === 'moonbase') {
    svg.appendChild(Kit.s('circle', Object.assign({ cx: 128, cy: 22, r: 12, fill: '#59d7ff' }, ink)));
    svg.appendChild(Kit.s('path', Object.assign({ d: 'M0 72 Q40 58 80 70 T160 66 V100 H0Z', fill: '#8a82d6' }, ink)));
    svg.appendChild(Kit.s('path', Object.assign({ d: 'M0 88 Q50 76 100 86 T160 84 V100 H0Z', fill: '#6c63c4' }, ink)));
    [[26, 80, 8, 2.4], [104, 90, 10, 2.8], [140, 78, 6, 2]].forEach(([x, y, rx, ry]) => svg.appendChild(Kit.s('ellipse', Object.assign({ cx: x, cy: y, rx, ry, fill: '#574fb0' }, ink))));
    svg.appendChild(Kit.s('path', Object.assign({ d: 'M44 70 a16 14 0 0 1 32 0z', fill: '#59d7ff' }, ink))); svg.appendChild(Kit.s('rect', Object.assign({ x: 40, y: 69, width: 40, height: 7, rx: 2, fill: '#d9d4ff' }, ink)));
  } else {
    [[30, 30, 14, '#ff5fa8', '#c2307a'], [120, 62, 20, '#8a5cf0', '#5a35b8'], [74, 78, 9, '#5ef0c8', '#2fa58a']].forEach(([x, y, r, c1, c2]) => { svg.appendChild(Kit.s('circle', Object.assign({ cx: x, cy: y, r, fill: c1 }, ink))); svg.appendChild(Kit.s('path', { d: `M${x - r} ${y + r * .2} q${r} ${-r * .3} ${2 * r} ${r * .2} a${r} ${r} 0 0 1 ${-2 * r} 0z`, fill: c2, opacity: .85 })); });
    svg.appendChild(Kit.s('ellipse', Object.assign({ cx: 120, cy: 62, rx: 32, ry: 6, fill: 'none', stroke: '#ffd93b', 'stroke-width': 2.4, transform: 'rotate(-16 120 62)' })));
  }
  scene.appendChild(svg);
  const seen = new Set(); let cur = -1, labels = false;
  const spots = SP.map((s, i) => {
    const b = Kit.h('button', 'hs-spot', { type: 'button', title: s.title, 'aria-label': s.title, style: `left:${s.x}%;top:${s.y}%` }, [s.icon || '⭐']);
    b.addEventListener('click', () => select(i));
    b.addEventListener('mouseenter', () => showTip(i)); b.addEventListener('focus', () => showTip(i)); b.addEventListener('mouseleave', hideTip); b.addEventListener('blur', hideTip);
    scene.appendChild(b); return b;
  });
  function showTip(i) { const s = SP[i]; tip.textContent = s.title; tip.style.left = s.x + '%'; tip.style.top = s.y + '%'; tip.classList.add('show'); }
  function hideTip() { if (!labels) tip.classList.remove('show'); }
  const labs = SP.map(s => { const t = Kit.h('div', 'hs-tip', { style: `left:${s.x}%;top:${s.y}%` }, [s.title]); return t; });
  scene.append(...labs, tip, guide, count);
  function select(i) {
    cur = i; seen.add(i);
    spots.forEach((b, k) => { b.classList.toggle('on', k === i); b.classList.toggle('seen', seen.has(k) && k !== i); });
    const s = SP[i]; iic.textContent = s.icon || '⭐'; Kit.setText(it, s.title); Kit.setText(id_, s.text || '');
    guide.style.left = s.x + '%'; guide.style.top = `calc(${s.y}% - 24px)`;
    Kit.setText(count, `🔍 ${seen.size} / ${n}`); ctx.say(`${s.icon || '⭐'} ${s.title}：${s.text || ''}` + (seen.size === n ? '  🎉 全部探索完！' : ''));
  }
  function nextSpot() { for (let k = 1; k <= n; k++) { const i = (cur + k + n) % n; if (!seen.has(i) || seen.size === n) { select(i); return; } } }
  ctx.setButtons([
    { id: 'next', label: '⏭ 下一個熱點', cls: 'mint', on: nextSpot },
    { id: 'labels', label: '🏷 顯示名稱', on: () => { labels = !labels; labs.forEach(l => l.classList.toggle('show', labels)); if (labels) tip.classList.remove('show'); ctx.label('labels', labels ? '🏷 隱藏名稱' : '🏷 顯示名稱'); } },
    { id: 'reset', label: '↺ 重來', cls: 'blue', on: () => { seen.clear(); cur = -1; spots.forEach(b => b.classList.remove('on', 'seen')); iic.textContent = '🔍'; Kit.setText(it, '搵搵閃閃發光嘅圓點'); Kit.setText(id_, d.intro || '㩒任何一個圓點，睇睇入面有咩資料。'); Kit.setText(count, `🔍 0 / ${n}`); guide.style.left = '8%'; guide.style.top = '90%'; ctx.say(d.intro || '㩒任何一個圓點，睇睇入面有咩資料。'); } }
  ]);
  stage.append(scene, info);
  Kit.setText(it, '搵搵閃閃發光嘅圓點'); Kit.setText(id_, d.intro || '㩒任何一個圓點，睇睇入面有咩資料。'); Kit.setText(count, `🔍 0 / ${n}`);
  guide.style.left = '8%'; guide.style.top = '90%'; ctx.say(d.intro || '㩒任何一個圓點，睇睇入面有咩資料。');
  return { layout(narrow, W) {
    const sh = narrow ? Math.min(Math.round(W * 1.0), 380) : 300, ih = narrow ? 138 : 124;
    scene.style.height = sh + 'px'; info.style.top = sh + 10 + 'px'; info.style.height = ih + 'px'; ctx.height(sh + 10 + ih + 2);
    labs.forEach(l => (l.style.maxWidth = narrow ? '46%' : '30%'));
  } };
});

/* ===== charts/quiz.js ===== */
/* quiz — data: {questions:[{q, options:[2-4], answer:index, explain?}], intro?}   tap an option to reveal. */
Journey.register('quiz', function (ctx) {
  const Q = ctx.data.questions, n = Q.length, stage = ctx.stage;
  const root = Kit.h('div', 'qz'); stage.appendChild(root);
  const prog = Kit.h('div', 'qz-prog'), score = Kit.fb('chip qz-score', '', { min: 11, max: 15, nowrap: true });
  root.appendChild(Kit.h('div', 'qz-top', null, [prog, score]));
  const qbox = Kit.fb('qz-q', '', { min: 13, max: 26, left: true }); root.appendChild(qbox);
  const opts = Kit.h('div', 'qz-opts'), exp = Kit.fb('qz-exp', '', { min: 11, max: 16, left: true });
  const left = Kit.h('div', '', { style: 'display:flex;flex-direction:column;gap:10px;min-height:0;min-width:0' }, [opts, exp]); opts.style.flex = '1';
  const side = Kit.h('div', 'qz-side'); let face = Kit.sprite(ctx.mascot); side.appendChild(face);
  const body = Kit.h('div', 'qz-body', null, [left, side]); root.appendChild(body);
  const end = Kit.h('div', 'qz-end'); let eImg = Kit.sprite('cat_cheer'); const eBig = Kit.fb('big', '', { min: 16, max: 34 }), eSm = Kit.fb('sm', '', { min: 11, max: 18 }); end.append(eImg, eBig, eSm); stage.appendChild(end);
  let cur = 0, correct = 0, answered = [], narrow = false;
  const letters = 'ABCD';
  function pips() { prog.textContent = ''; Q.forEach((_, i) => prog.appendChild(Kit.h('i', i === cur && answered[i] == null ? 'now' : answered[i] == null ? '' : answered[i] ? 'ok' : 'no'))); }
  function setFace(name) { const f = Kit.sprite(name); side.replaceChild(f, face); face = f; }
  function render() {
    end.style.display = 'none'; root.style.display = ''; const q = Q[cur];
    Kit.setText(score, `⭐ ${correct} / ${n}`); pips(); Kit.setText(qbox, `Q${cur + 1}. ${q.q}`);
    opts.textContent = ''; exp.classList.remove('show'); Kit.setText(exp, '');
    q.options.forEach((o, i) => {
      const b = Kit.h('button', 'qz-opt', { type: 'button', id: 'opt-' + i }); b.append(Kit.h('span', 'mk', null, [letters[i]]), Kit.fb('', o, { min: 11, max: 19, left: true }));
      b.addEventListener('click', () => choose(i)); opts.appendChild(b);
    });
    setFace(ctx.mascot); ctx.enable('next', answered[cur] != null); ctx.enable('peek', answered[cur] == null);
    ctx.say(ctx.data.intro && cur === 0 ? ctx.data.intro : '🤔 揀一個答案，㩒落去就知對唔對！');
    Kit.fitAll(root);
  }
  function reveal(pick) {
    const q = Q[cur]; [...opts.children].forEach((b, i) => { b.disabled = true; b.classList.toggle('right', i === q.answer); b.classList.toggle('wrong', pick === i && i !== q.answer); });
    Kit.setText(exp, (pick === q.answer ? '✅ 答啱！' : pick == null ? '👀 答案：' + q.options[q.answer] + '。' : '❌ 唔啱，答案係「' + q.options[q.answer] + '」。') + ' ' + (q.explain || '')); exp.classList.add('show');
    Kit.fitAll(exp.parentNode);
  }
  function choose(i) {
    if (answered[cur] != null) return; const ok = i === Q[cur].answer; answered[cur] = ok; if (ok) correct++;
    reveal(i); pips(); Kit.setText(score, `⭐ ${correct} / ${n}`); setFace(ok ? 'cat_cheer' : 'cat_think');
    ctx.say(ok ? '🎉 答啱喇！' : '💡 唔緊要，睇睇解釋再繼續。'); ctx.enable('next', true); ctx.enable('peek', false); ctx.label('next', cur === n - 1 ? '🏁 睇結果' : '⏭ 下一題');
  }
  function next() {
    if (answered[cur] == null) return;
    if (cur >= n - 1) { root.style.display = 'none'; end.style.display = 'flex'; const pct = correct / n; Kit.setText(eBig, `全部 ${n} 題，答啱 ${correct} 題！`); Kit.setText(eSm, pct >= .75 ? '🏆 好叻呀，你已經掌握呢一站！' : pct >= .4 ? '👍 唔錯，再睇一次內容會更穩陣。' : '🌱 返去睇睇上面嘅重點，再玩一次！'); end.textContent = ''; end.append(eImg = Kit.sprite(pct >= .5 ? 'cat_cheer' : 'cat_think'), eBig, eSm); Kit.fitAll(end); ctx.say('🏁 小測驗完成：' + correct + '/' + n); ctx.enable('next', false); ctx.label('next', '⏭ 下一題'); return; }
    cur++; render(); ctx.label('next', cur === n - 1 ? '🏁 睇結果' : '⏭ 下一題');
  }
  function reset() { cur = 0; correct = 0; answered = []; end.textContent = ''; end.append(eImg = Kit.sprite('cat_cheer'), eBig, eSm); ctx.label('next', '⏭ 下一題'); render(); }
  ctx.setButtons([
    { id: 'next', label: '⏭ 下一題', cls: 'mint', on: next },
    { id: 'peek', label: '👀 睇答案', on: () => { if (answered[cur] == null) { answered[cur] = false; reveal(null); pips(); setFace('cat_think'); ctx.enable('next', true); ctx.enable('peek', false); ctx.say('👀 已經顯示答案。'); } } },
    { id: 'reset', label: '↺ 重玩', cls: 'blue', on: reset }
  ]);
  render();
  return { layout(nw, W) { narrow = nw; if (!nw) { ctx.height(440); root.style.cssText = ''; body.style.gridTemplateColumns = ''; side.style.display = ''; opts.style.gridTemplateColumns = ''; qbox.style.height = ''; }
      else { const oh = Q.reduce((m, q) => Math.max(m, q.options.length), 2); ctx.height(30 + 12 + 108 + 12 + oh * 58 + 8 + 86 + 12); body.style.gridTemplateColumns = '1fr'; side.style.display = 'none'; opts.style.gridTemplateColumns = '1fr'; qbox.style.height = '108px'; }
    Kit.fitAll(root); } };
});

/* ===== charts/timeline.js ===== */
/* timeline — data: {events:[{when,icon?,title,text}]}   3-8 events. Cards alternate above/below the axis (desktop) or stack (narrow). */
Journey.register('timeline', function (ctx) {
  const ev = ctx.data.events, n = ev.length, stage = ctx.stage;
  const axis = Kit.h('div', 'tl-axis'); stage.appendChild(axis);
  const cards = [], dots = [], stems = [];
  ev.forEach((e, i) => {
    const stem = Kit.h('div', 'tl-stem'); stage.appendChild(stem); stems.push(stem);
    const c = Kit.h('div', 'card tl-card future', { role: 'button', tabindex: 0, 'aria-label': e.title });
    c.append(Kit.h('div', 'tl-top', null, [Kit.fb('chip tl-when', e.when, { min: 10, max: 13, nowrap: true }), Kit.fb('tl-icon', e.icon || '⭐', { min: 14, max: 22, nowrap: true })]),
      Kit.fb('tl-title', e.title, { min: 11, max: 16, left: true }), Kit.fb('tl-text', e.text || '', { min: 10, max: 14, left: true }));
    c.addEventListener('click', () => goto(i)); c.addEventListener('keydown', k => { if (k.key === 'Enter' || k.key === ' ') { k.preventDefault(); goto(i); } });
    stage.appendChild(c); cards.push(c);
    const dt = Kit.h('button', 'tl-dot', { type: 'button', 'aria-label': (i + 1) + '. ' + e.title }, [String(i + 1)]); dt.addEventListener('click', () => goto(i)); stage.appendChild(dt); dots.push(dt);
  });
  const ufo = Kit.h('div', 'tl-ufo'); ufo.appendChild(Kit.sprite(n % 2 ? 'ufo' : 'ufo_pink')); stage.appendChild(ufo);
  let cur = -1, pos = [], running = false, tw = null, narrowMode = false;
  function layout(narrow, W) {
    narrowMode = narrow; pos = [];
    if (!narrow) {
      const H = 440, ay = H / 2, padX = 18, slot = (W - 2 * padX) / n, cw = Math.min(236, slot * 1.9), ch = 150;
      ctx.height(H); Object.assign(axis.style, { left: padX / 2 + 'px', width: W - padX + 'px', top: ay - 2 + 'px', height: '5px', bottom: '', right: '' }); axis.classList.remove('v');
      ev.forEach((e, i) => {
        const x = padX + slot * (i + .5), up = i % 2 === 0, cx = Kit.clamp(x - cw / 2, 0, W - cw), top = up ? ay - 40 - ch - 6 : ay + 40 + 6;
        Object.assign(cards[i].style, { left: cx + 'px', top: top + 'px', width: cw + 'px', height: ch + 'px' });
        Object.assign(stems[i].style, { left: x - 2 + 'px', width: '4px', top: (up ? top + ch : ay) + 'px', height: (up ? ay - (top + ch) : top - ay) + 'px' });
        Object.assign(dots[i].style, { left: x + 'px', top: ay + 'px' }); pos.push({ x, y: ay });
      });
    } else {
      const ch = 128, gap = 16, ax = 24, top0 = 58, H = top0 + n * (ch + gap);
      ctx.height(H); Object.assign(axis.style, { left: ax - 2 + 'px', width: '5px', top: top0 - 24 + 'px', height: H - top0 + 8 + 'px' }); axis.classList.add('v');
      ev.forEach((e, i) => {
        const y = top0 + i * (ch + gap);
        Object.assign(cards[i].style, { left: ax + 34 + 'px', top: y + 'px', width: W - ax - 38 + 'px', height: ch + 'px' });
        Object.assign(stems[i].style, { left: ax + 2 + 'px', width: '34px', top: y + ch / 2 - 2 + 'px', height: '4px' });
        Object.assign(dots[i].style, { left: ax + 'px', top: y + ch / 2 + 'px' }); pos.push({ x: ax, y: y + ch / 2 });
      });
    }
    placeUfo(cur < 0 ? 0 : cur);
  }
  function placeUfo(i) { const p = pos[i]; if (!p) return; ufo.style.left = p.x + 'px'; ufo.style.top = (narrowMode ? p.y - 8 : p.y - 16) + 'px'; }
  function paint() {
    cards.forEach((c, i) => { c.classList.toggle('active', i === cur); c.classList.toggle('done', i < cur); c.classList.toggle('future', i > cur); dots[i].classList.toggle('active', i === cur); dots[i].classList.toggle('done', i < cur); });
    ctx.enable('prev', cur > 0); ctx.enable('next', cur < n - 1);
  }
  function goto(i, quiet) {
    i = Kit.clamp(i, 0, n - 1); const from = pos[Math.max(cur, 0)] || pos[0], to = pos[i]; cur = i; paint();
    if (tw) tw.cancel();
    if (from && to) tw = Kit.tween(700, t => { ufo.style.left = Kit.lerp(from.x, to.x, t) + 'px'; ufo.style.top = Kit.lerp(from.y, to.y, t) + (narrowMode ? -8 : -16) - Math.sin(t * Math.PI) * 14 + 'px'; });
    if (!quiet) ctx.say(`⭐ 第 ${i + 1}/${n} 站 · ${ev[i].when}：${ev[i].title}`);
  }
  async function play() {
    if (running) { running = false; ctx.label('play', '▶ 播放'); return; }
    running = true; ctx.label('play', '⏸ 暫停'); if (cur >= n - 1) cur = -1;
    while (running && cur < n - 1) { goto(cur + 1); await Kit.sleep(2200); }
    running = false; ctx.label('play', '▶ 播放');
  }
  ctx.setButtons([
    { id: 'prev', label: '⏮ 上一站', on: () => { running = false; goto(cur - 1); } },
    { id: 'play', label: '▶ 播放', cls: 'mint', on: play },
    { id: 'next', label: '⏭ 下一站', on: () => { running = false; goto(cur + 1); } },
    { id: 'reset', label: '↺ 重來', cls: 'blue', on: () => { running = false; cur = -1; paint(); placeUfo(0); ctx.label('play', '▶ 播放'); ctx.say(ctx.data.intro || '㩒「下一站」或「播放」，飛碟會帶你沿時間軸飛。'); ctx.enable('prev', false); } }
  ]);
  ctx.enable('prev', false); ctx.say(ctx.data.intro || '㩒「下一站」或「播放」，飛碟會帶你沿時間軸飛。');
  return { layout };
});

/* ===== audio.js ===== */
/* Alien Journey — ambient sound module (original work). One <audio loop> + a toggle button (#sound-btn) on every page.
   Browsers block autoplay, so sound starts OFF; the user taps "開啟宇宙聲效". The choice is remembered (localStorage)
   and, on the next page, we try to resume; if the browser refuses, the button pulses and one tap resumes.
   State is exposed on window.__sound = {on, playing, error} for tests. */
(function () {
  'use strict';
  const btn = document.getElementById('sound-btn');
  const S = (window.__sound = { on: false, playing: false, error: null });
  const store = (window.Kit && Kit.store) || { get() { return null; }, set() {} };
  const src = ((window.JOURNEY && JOURNEY.assets) || 'assets/') + 'audio/ambient.wav';
  const a = new Audio(); a.loop = true; a.preload = 'auto'; a.volume = 0.5; a.src = src; a.id = 'ambient';
  window.__ambient = a;
  const label = (on, playing) => {
    if (!btn) return;
    btn.setAttribute('aria-pressed', on ? 'true' : 'false');
    btn.classList.toggle('nudge', on && !playing);
    btn.textContent = !on ? '🔇 開啟宇宙聲效' : playing ? '🔊 聲效開' : '🔈 點擊繼續';
    btn.title = !on ? 'Turn on ambient UFO sound' : 'Mute ambient sound';
  };
  const sync = () => { S.playing = !a.paused; label(S.on, S.playing); };
  a.addEventListener('playing', sync); a.addEventListener('pause', sync);
  a.addEventListener('error', () => { S.error = 'audio load error'; });
  const play = () => a.play().then(() => { S.error = null; sync(); }).catch(e => { S.error = String(e && e.name); sync(); });
  const t0 = parseFloat(store.get('aj-sound-t') || '0');
  a.addEventListener('loadedmetadata', () => { if (t0 > 0 && a.duration) { try { a.currentTime = t0 % a.duration; } catch (e) {} } });
  setInterval(() => { if (!a.paused) store.set('aj-sound-t', String(a.currentTime)); }, 1000);
  window.addEventListener('pagehide', () => { if (!a.paused) store.set('aj-sound-t', String(a.currentTime)); });
  if (btn) btn.addEventListener('click', () => {
    if (!S.on || !S.playing) { S.on = true; store.set('aj-sound', 'on'); play(); }   // turn on, or resume after a page change
    else { S.on = false; store.set('aj-sound', 'off'); a.pause(); sync(); }           // mute
    label(S.on, S.playing);
  });
  S.on = store.get('aj-sound') === 'on';
  label(S.on, false);
  if (S.on) play();   // may be refused after navigation -> button pulses, one tap resumes
})();
